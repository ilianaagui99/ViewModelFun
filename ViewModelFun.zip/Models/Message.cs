namespace ViewModelFun.Models
{
    public class Message{
        public string YourMessage {get; set;}
    }
}